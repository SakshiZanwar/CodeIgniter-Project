<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function index() {
        //$this->load->view('common/header');
        //$this->load->view('index');
        //$this->load->view('common/footer');
    }

    function formValid() {
        $name = $this->input->post('email');

        if( !isset($name) ){
          $name = "The field should not blank!!";  
        }
        
        $data = array(
            'name' => $name,
        );

        $this->load->view('index',$data);
    }
}
?>