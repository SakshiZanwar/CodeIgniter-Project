<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller {
    public function __construct() {
        parent::__construct();
        //$this->lang->load('news');

        $this->load->model('news_model');
    }
    function index() {
        $data['title'] = $this->lang->line('news_title');

        $data['news'] = $this->news_model->get_news();

        $data['users'] = array('ram' , 'shyam');
        //$this->load->view('news', $data);
        //echo "<h1>Hello World!</h1>";
        //$this->load->view('home');
    }

    public function details() {
        echo "News Details ";
    }
}
?>