<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home2 extends CI_Controller {
    function index() {
        echo "<h1>Hello World!</h1>";
        //$this->load->view('home');
    }

    function details() {
        echo "Detailed World!";
    }
}
?>