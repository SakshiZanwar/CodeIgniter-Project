<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi"
      crossorigin="anonymous"
    />
    <link
      href="vendor/fontawesome-free/css/all.min.css"
      rel="stylesheet"
      type="text/css"
    />
    <style>
      .login_form_body {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
        height: 100vh;
        background-color: #335aca;
      }
      .login_form_img {
        display: flex !important;
      }

      .btn-user {
        font-size: 0.8rem;
        border-radius: 10rem;
        padding: 0.75rem 1rem;
      }
      .ligin_icon {
        font-size: 228px;
      }

      @media (max-width: 576px) {
        .container {
          padding: 0 30px !important;
        }
      }
    </style>
  </head>
  <body class="login_form_body bg-primary">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-9 bg-white py-5 border shadow-lg">
          <div class="row">
            <div
              class="col-lg-6 col-sm-12 d-flex justify-content-center login_form_img"
            >
              <i class="fas fa-sign-in-alt ligin_icon py-5"></i>
            </div>

            <div class="col-lg-6 col-sm-12 py-4 px-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Login here!</h1>
              </div>
              <form method="post" action="">
                <div class="form-group">
                  <div class="form-group">
                    <input
                      type="text"
                      name="username"
                      class="form-control rounded-pill form-control-user py-3"
                      placeholder="Enter User Name..."
                    />
                  </div>
                </div>

                <div class="form-group py-4">
                  <div class="form-group">
                    <input
                      name="username"
                      class="form-control rounded-pill form-control-user py-3"
                      placeholder="Password"
                      type="password"
                    />
                  </div>
                </div>
                <button
                  class="btn w-100 rounded-pill btn-primary py-3"
                  type="button"
                >
                  Login
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
      integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js"
      integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk"
      crossorigin="anonymous"
    ></script>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
