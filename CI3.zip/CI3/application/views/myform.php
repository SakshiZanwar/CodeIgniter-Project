<html>
<head>
<title>My Form</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('form'); ?>

<?php
    $emailErr = "";
    $passwordErr = "";

    if(isset($_POST['submit'])) {
        $email = ( !empty( $_POST['email'] )) ? $_POST['email'] : '';
        $password = ( !empty( $_POST['password'] )) ? $_POST['password'] : '';
        
        if (empty($email)) {
            $emailErr = "It should not be blank.";
        } else {
            if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/", $email)) {
                $emailErr = "Email is invalid";
            }
        }
    
        if (empty($password)) {
            $passwordErr = "It should not be blank.";
        } else {
            if (!preg_match("/^(?=.*[!@#$%^&*-])(?=.*[0-9])(?=.*[A-Z]).{8,20}$/", $password)) {
                $passwordErr = "Password is invalid";
            }
        }
    }
?>
<div class="container-fluid">
    <div class="form-container">
        <form>
            <div class="form-group">
                <label for="email">Email address</label>
                <input type="text" name="email" class="form-control" id="email" placeholder="Enter email" autocomplete="off">
                <span><?php echo ($emailErr != "")? $emailErr : '';?></span><br>
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <br>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" id="password" placeholder="Password" autocomplete="off">
                <span><?php echo ($passwordErr != "")? $passwordErr : '';?></span><br><br>
            </div>
            <input type="submit" name="submit"  value="Submit" class="btn btn-primary">
        </form>
    </div>
</div>
</body>
</html>